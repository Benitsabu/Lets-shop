<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Setup\Patch\Data;

use Magento\Customer\Model\Customer;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Customer\Setup\Patch\Data\UpdateIdentifierCustomerAttributesVisibility;

class CustomerAttribute implements DataPatchInterface
{
    private $moduleDataSetup;

    private $customerSetupFactory;

    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CustomerSetupFactory $customerSetupFactory
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->customerSetupFactory = $customerSetupFactory;
    }

    public function apply()
    {
        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
        $customerSetup->addAttribute(Customer::ENTITY, 'calling_code', [
            'type' => 'varchar',
            'label' => 'Telephone Code',
            'input' => 'text',
            'sort_order' => 100,
            'position' => 100,
            'required' => false,
            'visible' => true,
            'system' => false
        ]);
        $customerAccountCode =$customerSetup->getEavConfig()->clear()
            ->getAttribute(Customer::ENTITY, 'calling_code');
        if ($customerAccountCode->getAttributeId()) {
            $usedInForms =  ['adminhtml_customer'];
            $data = [];
            foreach ($usedInForms as $formCode) {
                $data[] = ['form_code' => $formCode, 'attribute_id' => $customerAccountCode->getAttributeId()];
            }
            $this->moduleDataSetup->getConnection()->insertMultiple(
                $this->moduleDataSetup->getTable('customer_form_attribute'),
                $data
            );
            $this->moduleDataSetup->getConnection()->endSetup();
        }
    }

    /**
     * {@inheritdoc}
     */
    public static function getDependencies()
    {
        return [
            UpdateIdentifierCustomerAttributesVisibility::class,
        ];
    }

    public function getAliases()
    {
        return [];
    }
}
