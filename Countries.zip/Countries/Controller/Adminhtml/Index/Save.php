<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Seq\Countries\Model\CountryFactory;
use Magento\Framework\App\RequestInterface;
use Seq\Countries\Api\Data\CountryInterfaceFactory;
use Seq\Countries\Api\CountryRepositoryInterface;
use Magento\Directory\Model\CountryFactory as CountryData;


class Save extends \Magento\Backend\App\Action
{
    /**
     * @var CountryRepositoryInterface
     */
    private $countryRepository;

    /**
     * @var CountryInterfaceFactory
     */
    private $countryInterfaceFactory;
    /**
     * @var CountryData
     */
    private $countryFactory;
    /**
     * @var RequestInterface
     */
    private $request;
    /**
     * @var CountryFactory
     */
    private $countryItem;

    /**
     * @param Context $context
     * @param RequestInterface $request
     * @param CountryFactory $countryItem
     * @param CountryInterfaceFactory $countryInterfaceFactory
     * @param CountryRepositoryInterface $countryRepository
     * @param CountryData $countryData
     */
    public function __construct(
        Context $context,
        RequestInterface $request,
        CountryFactory $countryItem,
        CountryInterfaceFactory $countryInterfaceFactory,
        CountryRepositoryInterface $countryRepository,
        CountryData $countryData
    ) {
        $this->request = $request;
        $this->countryItem = $countryItem;
        $this->countryRepository = $countryRepository;
        $this->countryInterfaceFactory = $countryInterfaceFactory;
        $this->countryFactory = $countryData;
        parent::__construct($context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->request->getPostValue();
        $date = date("m/d/Y h:i:s a", time());

        $countryCode = $this->getCountryname($data['country_id']);

        $collection = $this->countryInterfaceFactory->create();
        $collection->setCountryName($countryCode);
        $collection->setCountryCode($data['country_id']);
        $collection->setCallingCode($data['calling_code']);
        if (array_key_exists('flag_image',$data)) {
            $collection->setFlagImage($data['flag_image'][0]['url']);
        }
        $collection->setStatus($data['status']);
        $collection->setMaximumDigit($data['maximum_digit']);
        $collection->setCreatedAt($date);

        $this->countryRepository->save($collection);
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * @param $countryCode
     * @return string
     */
    public function getCountryname($countryCode)
    {
        $country = $this->countryFactory->create()->loadByCode($countryCode);
        return $country->getName();
    }
}
