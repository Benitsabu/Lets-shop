<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;
 
interface CountryInterface extends ExtensibleDataInterface
{
    const COUNTRY_ID    = 'country_id';
    const COUNTRY_NAME  = 'country_name';
    const COUNTRY_CODE  = 'country_code';
    const CALLING_CODE  = 'calling_code';
    const FLAG_IMAGE    = 'flag_image';
    const STATUS        = 'status';
    const MAX_DIGIT     = 'max_digit';
    const CREATED_AT    = 'created_at';
    const UPDATED_AT    = 'updated_at';

    /**
     * @return int
     */
    public function getId();
 
    /**
     * Get CountryName
     *
     * @return string|null
     */

    public function getCountryName();
    
   /**
    * Get CountryCode
    *
    * @return string|null
    */

    public function getCountryCode();

    /**
     * Get CallingCode
     *
     * @return string|null
     */

    public function getCallingCode();
    
    /**
     * Get FlagImage
     *
     * @return string|null
     */

    public function getFlagImage();
    
    /**
     * Get Status
     *
     * @return string|null
     */

    public function getStatus();

     /**
      * Get Max Digit
      *
      * @return string|null
      */

    public function getMaximumDigit();
    
    /**
     * Get Created At
     *
     * @return string|null
     */
    public function getCreatedAt();
    
    /**
     * Get Updated At
     *
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * @param int $country_id
     * @return CountryInterface
     */
    public function setId($country_id);

    /**
     * @param $country_name
     * @return CountryInterface
     */
    public function setCountryName($country_name);

    /**
     * @param $country_code
     * @return CountryInterface
     */
    public function setCountryCode($country_code);

    /**
     * @param $calling_code
     * @return CountryInterface
     */
    public function setCallingCode($calling_code);
    
    /**
     * @param $flag_image
     * @return CountryInterface
     */
    public function setFlagImage($flag_image);
    
    /**
     * @param $status
     * @return CountryInterface
     */
    public function setStatus($status);

    /**
     * @param $max_digit
     * @return CountryInterface
     */
    public function setMaximumDigit($max_digit);
    
    /**
     * @param $created_at
     * @return CountryInterface
     */
    public function setCreatedAt($created_at);
    
    /**
     * @param $updated_at
     * @return CountryInterface
     */
    public function setUpdatedAt($updated_at);
}
