<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Api\Data;

interface CountrySearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{
    /**
     * Get Country Data.
     *
     * @return \Seq\Countries\Api\Data\CountryInterface[]
     */
    public function getItems();

    /**
     * Set Country Data.
     *
     * @param \Seq\Countries\Api\Data\CountryInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
