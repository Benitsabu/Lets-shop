<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Seq\Countries\Api\Data\CountryInterface;

interface CountryRepositoryInterface
{
    /**
     * @param int $country_id
     * @return \Seq\Countries\Api\Data\CountryInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($country_id);

    /**
     * Save Data
     *
     * @param \Seq\Countries\Api\Data\CountryInterface
     * @return \Seq\Countries\Api\Data\CountryInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(CountryInterface $country);

    /**
     * Delete the country_id
     * @param $country_id
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($country_id);

    /**
     * Load data collection by given search criteria
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return \Seq\Countries\Api\Data\CountrySearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);
}
