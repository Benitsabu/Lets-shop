<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Block\Adminhtml\Edit;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

/**
 * Class BackButton
 */
class AddNew extends GenericButton implements ButtonProviderInterface
{
    /**
     * @return array
     */
    public function getButtonData()
    {
        return [
            'label' => __('Add New'),
            'on_click' => sprintf("location.href = '%s';", $this->getNewUrl()),
            'class' => 'save primary',
            'sort_order' => 10
        ];
    }

    /**
     *
     * @return string
     */
    public function getNewUrl()
    {
        return $this->getUrl('seqcountries/index/Addnew');
    }
}
