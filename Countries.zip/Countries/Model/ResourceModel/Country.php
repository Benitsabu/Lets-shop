<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Country extends AbstractDb
{
    public function _construct()
    {
        $this->_init('countries_list', 'country_id');
    }
}
