<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Model\ResourceModel\Country;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'country_id';

    public function _construct()
    {
        $this->_init(
            \Seq\Countries\Model\Country::class,
            \Seq\Countries\Model\ResourceModel\Country::class
        );
        $this->_idFieldName = 'country_id';
    }
}
