<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Seq\Countries\Model\countryFactory;
use Seq\Countries\Api\Data\CountryInterface;
use Seq\Countries\Model\ResourceModel\Country;
use Seq\Countries\Api\Data\CountryInterfaceFactory;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Api\SearchCriteriaInterface;
use Seq\Countries\Api\Data\CountrySearchResultsInterfaceFactory;
use Magento\Framework\Reflection\DataObjectProcessor;
use Seq\Countries\Model\ResourceModel\Country\CollectionFactory;

class CountryRepository implements \Seq\Countries\Api\CountryRepositoryInterface
{
    /**
     * @var countryFactory
     */
    private $countryFactory;
    /**
     * @var ResourceModel\Country
     */
    private $countryResource;
    /**
     * @var \Seq\Countries\Api\Data\CountryInterfaceFactory
     */
    private $countryDataFactory;
    /**
     * @var \Magento\Framework\Api\ExtensibleDataObjectConverter
     */
    private $dataObjectConverter;
    /**
     * @var DataObjectHelper
     */
    private  $dataObjectHelper;
    /**
     * @var DataObjectProcessor
     */
    private $dataObjectProcessor;
    /**
     * @var CountrySearchResultsInterfaceFactory
     */
    private $searchResultFactory;
    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;
    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * CountryRepository constructor.
     * @param CountryFactory $countryFactory
     * @param Country $countryResource
     * @param CountryInterfaceFactory $countryDataFactory
     * @param ExtensibleDataObjectConverter $dataObjectConverter
     * @param DataObjectHelper $dataObjectHelper
     * @param CountrySearchResultsInterfaceFactory $searchResultFactory
     * @param DataObjectProcessor $dataObjectProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(
        CountryFactory $countryFactory,
        Country $countryResource,
        CountryInterfaceFactory $countryDataFactory,
        ExtensibleDataObjectConverter $dataObjectConverter,
        DataObjectHelper $dataObjectHelper,
        CountrySearchResultsInterfaceFactory $searchResultFactory,
        DataObjectProcessor $dataObjectProcessor,
        CollectionProcessorInterface $collectionProcessor,
        CollectionFactory $collectionFactory
    ) {
        $this->countryFactory = $countryFactory;
        $this->countryResource = $countryResource;
        $this->countryDataFactory = $countryDataFactory;
        $this->dataObjectConverter = $dataObjectConverter;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->searchResultFactory = $searchResultFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * @param int $countryId
     * @return CountryInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($country_id)
    {
        $countryObj = $this->countryFactory->create();
        $this->countryResource->load($countryObj, $country_id);
        if (!$countryObj->getId()) {
            throw new NoSuchEntityException(__('Item with id "%1" does not exist.', $country_id));
        }
        $data = $this->countryDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $data,
            $countryObj->getData(),
            CountryInterface::class
        );
        $data->setId($countryObj->getId());
        return $data;
    }

    /**
     * Save Country Data
     *
     * @param CountryInterface
     * @return CountryInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(CountryInterface $country)
    {
        $countryData = $this->dataObjectConverter->toNestedArray(
            $country,
            [],
            CountryInterface::class
        );
        $countryModel = $this->countryFactory->create();
        $countryModel->setData($countryData);
        try {
            $countryModel->setId($country->getId());
            $this->countryResource->save($countryModel);
            if ($country->getId()) {
                $country = $this->getById($country->getId());
            } else {
                $country->setId($countryModel->getId());
            }
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__('Could not save the data: %1', $exception->getMessage()));
        }
        return $country;
    }

    /**
     * Delete the Country by Country id
     * @param $countryId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($countryId)
    {
        $countryObj = $this->countryFactory->create();
        $this->countryResource->load($countryObj, $countryId);
        $this->countryResource->delete($countryObj);
        if ($countryObj->isDeleted()) {
            return true;
        }
        return false;
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return \Seq\Countries\Api\Data\CountrySearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $collection = $this->collectionFactory->create();

        $this->collectionProcessor->process($searchCriteria, $collection);

        $searchResults = $this->searchResultFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setItems($collection->getItems());
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
}
