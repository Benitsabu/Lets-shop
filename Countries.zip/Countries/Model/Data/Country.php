<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Model\Data;

use Seq\Countries\Api\Data\CountryInterface;

class Country extends \Magento\Framework\Api\AbstractExtensibleObject implements CountryInterface
{
    /**
     * Get Id
     *
     * @return int
     */
    public function getId()
    {
        return $this->_get(self::COUNTRY_ID);
    }

    /**
     * Get ContryName
     *
     * @return string|null
     */
    public function getCountryName()
    {
        return $this->_get(self::COUNTRY_NAME);
    }
    
    /**
     * Get CountryCode
     *
     * @return string|null
     */
    public function getCountryCode()
    {
        return $this->_get(self::COUNTRY_CODE);
    }
    
    /**
     * Get CallingCode
     *
     * @return string|null
     */
    public function getCallingCode()
    {
        return $this->_get(self::CALLING_CODE);
    }
    
    /**
     * Get FlagImage
     *
     * @return string|null
     */
    public function getFlagImage()
    {
        return $this->_get(self::FLAG_IMAGE);
    }

    /**
     * Get Status
     *
     * @return string|null
     */
    public function getStatus()
    {
        return $this->_get(self::STATUS);
    }

    /**
     * Get Max Digit
     *
     * @return string|null
     */
    public function getMaximumDigit()
    {
        return $this->_get(self::MAX_DIGIT);
    }
    
    /**
     * Get CreatedAt
     *
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }
    
    /**
     * Get UpdatedAt
     *
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set CountryDeatils
     *
     * @param string $updated_at
     * @return $this
     */
    public function setUpdatedAt($updated_at)
    {
        return $this->setData(self::UPDATED_AT, $updated_at);
    }

    /**
     * Set CountryDeatils
     *
     * @param string $created_at
     * @return $this
     */
    public function setCreatedAt($created_at)
    {
        return $this->setData(self::CREATED_AT, $created_at);
    }

    /**
     * Set CountryDeatils
     *
     * @param string $status
     * @return $this
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * Set CountryDeatils
     *
     * @param string $max_digit
     * @return $this
     */
    public function setMaximumDigit($max_digit)
    {
        return $this->setData(self::MAX_DIGIT, $max_digit);
    }

    /**
     * Set CountryDeatils
     *
     * @param string $flag_image
     * @return $this
     */
    public function setFlagImage($flag_image)
    {
        return $this->setData(self::FLAG_IMAGE, $flag_image);
    }

    /**
     * Set CountryDeatils
     *
     * @param string $calling_code
     * @return $this
     */
    public function setCallingCode($calling_code)
    {
        return $this->setData(self::CALLING_CODE, $calling_code);
    }

    /**
     * Set CountryDeatils
     *
     * @param string $country_code
     * @return $this
     */
    public function setCountryCode($country_code)
    {
        return $this->setData(self::COUNTRY_CODE, $country_code);
    }

    /**
     * Set CountryDeatils
     *
     * @param string $country_name
     * @return $this
     */
    public function setCountryName($country_name)
    {
        return $this->setData(self::COUNTRY_NAME, $country_name);
    }
   
    /**
     * Set ID
     *
     * @param int $country_id
     * @return $this
     */
    public function setId($country_id)
    {
        return $this->setData(self::COUNTRY_ID, $country_id);
    }
}
