<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Model\Country;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Seq\Countries\Model\ResourceModel\Country\CollectionFactory;

class DataProvider extends AbstractDataProvider
{
    /**
     * @var CollectionFactory
     */
    private $countryFactory;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $countryFactory
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $countryFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->countryFactory = $countryFactory;
        $this->collection = $this->countryFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);

    }
}
