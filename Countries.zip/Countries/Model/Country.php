<?php
/**
 * @package Seq_Countries
 */
declare(strict_types=1);

namespace Seq\Countries\Model;

use Magento\Framework\Model\AbstractModel;

class Country extends AbstractModel
{
   /**
    * @return void
    */
    public function _construct()
    {
        $this->_init(\Seq\Countries\Model\ResourceModel\Country::class);
    }
}
