<?php
	
	namespace Webkul\Test\Model;

	class Product
	{
		public function afterGetName(\Magento\Catalog\Model\Product $subject, $result) {
			return "Plugin ".$result; // Adding Apple in product name
		}
	}