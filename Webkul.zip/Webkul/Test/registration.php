<?php
/**
 * @package Webkul_Test
 */
\Magento\Framework\Component\ComponentRegistrar::register(
\Magento\Framework\Component\ComponentRegistrar::MODULE,
'Webkul_Test',
__DIR__
);